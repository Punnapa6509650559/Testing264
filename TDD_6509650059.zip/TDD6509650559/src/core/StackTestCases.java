package core;

import junit.framework.TestCase;

public class StackTestCases extends TestCase {
	
	//TC1

    public void testCreateNewEmptyStack() {
        Stack s1 = new Stack();
        assertEquals(true, s1.isEmpty());
    }
    
    //TC2

    public void testPushElmToTop() throws Exception {
        Stack s1 = new Stack();
        boolean isFullStack = s1.isFull();

        if (!isFullStack) {
            s1.push(1);
        }

        assertEquals(1, s1.getTop());
    }
    
    //TC3

    public void testPushSameType() throws Exception {
        Stack s1 = new Stack();
        boolean isFullStack = s1.isFull();

        if (!isFullStack) {
            s1.push(1);
            assertEquals(1, s1.getTop());
        }

        try {
            s1.push("test");
            fail("Expected an exception to be thrown");
        } catch (Exception e) {
            assertEquals("All elements in the stack must be of type Integer.", e.getMessage());
        }
    }
    
    //TC4
    public void testLastInFirstOut() throws Exception {
        Stack s1 = new Stack();
        try {
            s1.push(5);
            s1.push(6);
            s1.push(9);

            assertEquals("Pop should return the last element (LIFO)", 9, s1.pop());
            assertEquals("Pop should return the second-to-last element", 6, s1.pop());
            assertEquals("Pop should return the first element", 5, s1.pop());
        } catch (Exception e) {
            fail("Unexpected exception: " + e.getMessage());
        }
    }
    //TC5
    public void testStackMoreThanLimit() throws Exception {
       
        int capacity = 10;
        
        Stack s1 = new Stack(capacity);

       
        for (int i = 1; i <= capacity; i++) {
            s1.push(i);
        }

      
        try {
            s1.push(capacity + 1);
            fail("Expected an exception to be thrown");
        } catch (Exception e) {
            assertEquals("Stack is full.", e.getMessage());
        }
    }
}


