package core;

import junit.framework.TestCase;

public class StackTestCases extends TestCase {

    public void testCreateNewEmptyStack() {
        Stack s1 = new Stack();
        assertEquals(true, s1.isEmpty());
    }

    public void testPushElmToTop() throws Exception {
        Stack s1 = new Stack();
        boolean isFullStack = s1.isFull();

        if (!isFullStack) {
            s1.push(1);
        }

        assertEquals(1, s1.getTop());
    }

    public void testLastInFirstOut() throws Exception {
        Stack s1 = new Stack();
        try {
            s1.push(5);
            s1.push(6);
            s1.push(9);

            assertEquals("Pop should return the last element (LIFO)", 9, s1.pop());
            assertEquals("Pop should return the second-to-last element", 6, s1.pop());
            assertEquals("Pop should return the first element", 5, s1.pop());
        } catch (Exception e) {
            fail("Unexpected exception: " + e.getMessage());
        }
    }
}

