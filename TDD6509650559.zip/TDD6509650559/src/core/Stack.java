package core;

public class Stack implements Istack {

    private int top;
    private int maxSize;
    private int[] stackArray;

    public Stack() {
        
        maxSize = 10; 
        stackArray = new int[maxSize];
        top = -1;
    }

    @Override
    public int getSize() {
        return top + 1;
    }

    @Override
    public boolean isEmpty() {
        return (top == -1);
    }

    @Override
    public boolean isFull() {
        return (top == maxSize - 1);
    }

    @Override
    public void push(Object element) throws Exception {
        if (!isFull()) {
            if (top != -1 && !(element instanceof Integer)) {
                throw new Exception("All elements in the stack must be of type Integer.");
            }
            stackArray[++top] = (int) element;
        } else {
            throw new Exception("Stack is full.");
        }
    }


    @Override
    public Object getTop() {
        if (!isEmpty()) {
            return stackArray[top];
        } else {
            return null;  }
    }
    
    @Override
    public Object pop() {
        if (top >= 0) {
            return stackArray[top--];
        }
        return null;
    }



}


	
	
	
	

