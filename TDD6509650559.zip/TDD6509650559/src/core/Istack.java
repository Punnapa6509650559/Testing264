package core;

public interface Istack {
	int getSize();
	boolean isEmpty();
	boolean isFull();
	void push(Object element) throws Exception;
	Object getTop();
	Object pop();

}
